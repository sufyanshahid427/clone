//For Loop for Multiple Video 

let i = 0 ;
let ytArr = [
    //["Img File Name " , "Youtube Video Link " , " Video Title"]
    ["LDabs-XHeA4.jpg","LDabs-XHeA4","How To Make a Responsive Coffee Shop ..."],
    ["hO1IitYxz4c.jpg","hO1IitYxz4c","How To Create a Responsive Food ..."],
    ["QQYV_X3A4wI.jpg","QQYV_X3A4wI","How To Make a Full Responsive Traveling ..."],
    ["ujM23hruYGM.jpg","ujM23hruYGM","How To Make a Full Responsive Event ..."],
    ["mNlzrc5A0Ek.jpg","mNlzrc5A0Ek","How to Make a Responsive website ..."],
    ["0wfg2inC-0k.jpg","0wfg2inC-0k","How To Make a The Wedding WebSite Using ..."],
    ["dP2IuOhBPxg.jpg","dP2IuOhBPxg","How To Create Barber Website Using HTML ..."],
    ["LaEmeVZcKF8.jpg","LaEmeVZcKF8","How to Make A Portfolio Website Using HTML ..."],
    ["wbJz8A4erMk.jpg","wbJz8A4erMk","How to Make a Responsive Simple Food ..."]   
]

let len = ytArr.length;
let text = "";



// ytArr[i][1] is call Video Link in ytArr array 
// ytArr[i][0] is call Video thumbnail in ytArr array 
// ytArr[i][3] is call Video Title in ytArr array 

